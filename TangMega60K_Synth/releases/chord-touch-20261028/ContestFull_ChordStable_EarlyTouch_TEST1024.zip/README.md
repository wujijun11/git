# 和弦稳定混音＋触摸提前上报：本地测试版

- 下载文件：fpga/ContestFull_ChordStable_EarlyTouch_TEST1024.fs；GW5AT-60B，SRAM Program。
- GUI工程：fpga-source/full/ContestFull.gprj；需要整个fpga-source目录。
- 普通和弦不再只按声部数量减半；实际超出峰值余量时仍会压缩保护。
- 按键状态在前两字节收到后上报，滑条仍读取完整43字节；菜单操作保留。
- 54项ModelSim、PCM数值分析和完整时序已核对。没有自动下载、没有推送。
- 本版尚未上板；旧版OLED基本显示获用户确认，不代替本版完整实测；5×5待实测。
- 真实手指到声音延迟、长时稳定性、听感仍待实测，旧核心板熄灯问题未宣称修复。
- 技术总结及接入/回退方法见fpga-source/docs/和弦稳定混音与触摸提前上报实现说明_20261028.md。
