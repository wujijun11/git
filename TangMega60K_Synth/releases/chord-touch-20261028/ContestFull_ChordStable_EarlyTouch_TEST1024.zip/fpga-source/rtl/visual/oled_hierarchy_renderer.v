// generate-hierarchy-font.py生成。四行16像素文字，表达单位不混用。
module oled_hierarchy_renderer #(
    parameter FONT_FILE="rtl/audio/rom/menu_hierarchy_font.hex"
)(
    input wire clk,input wire [2:0] screen_page,input wire [6:0] column,
    input wire [3:0] view,input wire [1:0] zone,expression_mode,
    input wire recording,playing,guide,busy,input wire [7:0] error,
    input wire [15:0] record_digits,control_digits,
    input wire control_negative,input wire [7:0] control_percent,
    output wire [7:0] data
);
    reg [55:0] text;
    wire continuous=view==0;
    wire [7:0] percent=control_percent>100?8'd100:control_percent;
    wire [14:0] fill_end=({7'd0,percent}<<6)+({7'd0,percent}<<5)+
        ({7'd0,percent}<<4)+({7'd0,percent}<<2); // percent*116
    wire [14:0] coordinate=column>=6?({8'd0,column}-15'd6)*15'd100:15'd0;
    wire fill=column>=6 && column<=121 && coordinate<fill_end;
    wire [7:0] bar=(column==4 || column==123)?(screen_page[0]?8'h07:8'hfc):
        column>4 && column<123?(screen_page[0]?(fill?8'h07:8'h04):(fill?8'hfc:8'h04)):8'd0;
    always @*begin
        text=0;
        case(screen_page[2:1])
            0:if(continuous)case(expression_mode)
                0:text=56'h00000003358695;
                1:text=56'h00000003358ad0;
                default:text=56'h00000003358ad1;
                endcase
              else case(view)
                1:text=56'h00000000116210;
                2:text=56'h0000000911cac6;
                3:text=56'h0000000284cb15;
                4:text=56'h0000000284cb95;
                5:text=56'h0000000284e495;
                6:text=56'h0000000284e1c2;
                7:text=56'h000000034a8c98;
                default:text=56'h00000005eb8e1b;
              endcase
            1:if(continuous)begin
                if(expression_mode==1)begin
                    text=56'h0004081035cad0;
                    text[20:14]=control_negative?7'd98:7'd87;
                    text[27:21]=7'd1+{3'd0,control_digits[15:12]};
                    text[34:28]=7'd1+{3'd0,control_digits[11:8]};
                    text[41:35]=7'd1+{3'd0,control_digits[7:4]};
                    text[48:42]=7'd1+{3'd0,control_digits[3:0]};
                end else begin
                    text=expression_mode==0?56'h00380810200695:56'h00380810202cd8;
                    text[27:21]=7'd1+{3'd0,control_digits[11:8]};
                    text[34:28]=7'd1+{3'd0,control_digits[7:4]};
                    text[41:35]=7'd1+{3'd0,control_digits[3:0]};
                end
              end else case(view)
                1:text=56'h386cd188708ac6;
                2:text=56'h54da4952e54b15;
                3:text=56'h182d0a03c7cf1d;
                4:text=56'h048d2a404881a2;
                5:text=56'h9f3a6cc97298b0;
                6:text=56'ha748ad12b40695;
                7:text=56'h58acd2a52a13a6;
                default:text=56'hab517ae58acd2d;
              endcase
            2:begin
                if(error!=0)text=56'h00000000001c37;
                else if(busy)text=56'h000000000f5e3b;
                else if(recording)text=56'h000000000f8c98;
                else if(playing)text=56'h000000000f8d2d;
                else if(guide)text=56'h000000000f97ae;
                else text=56'h000000000fdd39;
                text[34:28]=7'd1+{3'd0,record_digits[15:12]};
                text[41:35]=7'd1+{3'd0,record_digits[11:8]};
                text[48:42]=7'd1+{3'd0,record_digits[7:4]};
                text[55:49]=7'd1+{3'd0,record_digits[3:0]};
            end
            default:if(!continuous)text=56'h0034aaa6a3d9b2;
                else if(expression_mode==1)text=56'h0002eaab96ed15;
                else if(expression_mode==2)text=56'h0166c61c17ed5e;
                else text=56'h00488936ad19b2;
        endcase
    end
    reg [7:0] font[0:4096-1];
    reg [7:0] pixel,bar_pixel;
    reg inverse,use_bar;
    wire [6:0] glyph=text[column[6:4]*7+:7];
    initial $readmemh(FONT_FILE,font);
    always @(posedge clk)begin
        pixel<=font[{glyph,screen_page[0],column[3:0]}];
        inverse<=!continuous && screen_page[2:1]==1 && column[6:5]==zone;
        use_bar<=continuous && screen_page[2:1]==2;
        bar_pixel<=bar;
    end
    assign data=use_bar?bar_pixel:pixel^{8{inverse}};
endmodule
