# 分层菜单与滑条表情：本地测试版

- 下载文件：fpga/ContestFull_MenuExpression_TEST1024.fs，GW5AT-60B，SRAM Program。
- GUI工程：fpga-source/full/ContestFull.gprj；请保留整个fpga-source目录。
- 主菜单：声音、表情、录放、曲谱；长按左端进入，短触松手选择，菜单右长按回音量。
- 表情：音量百分比、带符号弯音音分、颤音深度百分比；切换不覆盖音量。
- 普通选项成功后显示波形，触摸回音量；表情闲置10秒显示波形，触摸恢复原表情。
- 旧10秒版保留；新版本未上板。OLED和5×5灯板待实测，既有核心熄灯故障未确认修复。
- 未自动下载、未推送。新层级/表情类型尚未在旧Windows/手机客户端完整展示。
- 实际仿真、像素比较、完整时序与限制见实现说明.md、manifest.json及fpga-source/docs/reports/。
