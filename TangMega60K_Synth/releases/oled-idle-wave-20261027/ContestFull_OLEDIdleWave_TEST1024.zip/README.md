# OLED空闲实时波形：独立本地测试版

- 位流：fpga/ContestFull_OLEDIdleWave_TEST1024.fs，GW5AT-60B，SRAM Program；尚未上板。
- 滑条空闲3秒显示真实左声道波形；触摸恢复原页面，手势继续有效。
- 总菜单和子页均保留状态，不再空闲自动跳回音量。原长按操作、录放与音乐功能保持。
- 原R2位流保留；音色、混音增益策略、PLL、引脚/时序约束、C3与客户端不改。
- 板载RGB仍显示启动诊断颜色。先核对绿灯、蓝牙握手、实体发声，再验收OLED。
- GUI：fpga-source/full/ContestFull.gprj；保留完整源码与full/rtl ROM副本。GAO仅在构建/GUI副本中关闭。
- 24项选定ModelSim与实际STA结果见实现说明及fpga-source/docs/reports；不是实板通过声明。
- preview中的PNG来自实际仿真I2C捕获，非屏幕实拍；当前输出左声道时间窗约10.667ms。
- 不自动下载，不上传或合并main；原平滑版本启动故障根因仍未确认。
