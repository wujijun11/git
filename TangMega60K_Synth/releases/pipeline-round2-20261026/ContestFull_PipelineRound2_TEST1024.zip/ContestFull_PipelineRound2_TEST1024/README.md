# 第二轮本地测试：用寄存器改善时序

- 本地分支：codex/timing-resource-round2。原OLED版、上一TimingTouch测试版均保留。
- 位流：fpga/ContestFull_PipelineRound2_TEST1024.fs；GW5AT-60B，SRAM Program。未上板验证。
- GUI工程：fpga-source/full/ContestFull.gprj。必须保留整个fpga-source目录；GAO仅在交付副本关闭。
- 功能：沿用OLED、64复音、四区菜单、1024行曲谱、录放与等候学习；引脚和客户端不变。
- 原理/职责/问题处理见技术总结.md；实际结果见验证结果.md；原始报告见evidence。
- 复现：在fpga-source内执行scripts/verify-pipeline-round2.ps1，指定Python和ModelSimBin；加-Build运行Gowin。
- Python需要3.11+；中文工作路径可保留，但StageParent须指向可写的英文路径。
- 不宣称整机物理演奏延迟或64音实测频谱已经达标。
