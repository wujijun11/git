# OLED菜单闲置10秒：独立测试版

- FPGA位流：fpga/ContestFull_OLEDIdle10s_TEST1024.fs，GW5AT-60B，SRAM Program。
- 菜单/音量页闲置10秒后显示波形；触摸恢复原页面，录放/菜单状态保留。
- GUI源码：fpga-source/full/ContestFull.gprj，必须保留整个fpga-source文件夹。
- 本版未上板；核心板熄灯/蓝牙和琴键失效的根因尚未确认，不宣称已修复。
- 不改PLL、引脚、时序约束、音源、C3、电脑与手机程序；原3秒FS未覆盖。
- 未自动下载/推送；请先排查供电和接线，稳定后再由用户手动测试。
- 复现和真实仿真/构建证据见实现说明.md与manifest.json。
