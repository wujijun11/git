# 滑条音量演奏模式：独立本地测试版

- 位流：fpga/ContestFull_SliderVolume_TEST1024.fs；GW5AT-60B，SRAM Program，尚未上板。
- GUI工程：fpga-source/full/ContestFull.gprj，须保留完整fpga-source及full/rtl ROM目录。
- 操作见使用说明.md；原理、模块职责与剩余问题见实现说明.md；实际数据见验证结果.md。
- 新OLED显示音量百分比/刻度；菜单保留四组选项与高亮。preview是数字仿真像素预览，不是实屏照片。
- 分支codex/slider-volume-performance；未上传或合并main，旧FIFO写缓存测试版保持。
- Windows/C3/手机无需刷写；本轮未新增远端客户端界面，原0x83保留最后菜单页面语义。
- 复现：在fpga-source中运行scripts/verify-slider-volume.ps1，传入Python3.11+、ModelSim路径；加-Build进行Gowin构建。
