# 本地测试版：完整OLED主工程时序与触摸延迟

- 分支：codex/timing-latency-oled；只在本地，未合并或推送main。
- 下载：fpga/ContestFull_TimingTouch_TEST1024.fs，GW5AT-60B，SRAM Program；本次未下载板卡。
- GUI工程：fpga-source/full/ContestFull.gprj，保留整个fpga-source目录及full/rtl查找表。
- 功能沿用OLED＋等候学习版；Windows/C3/手机无需更新。四针OLED和其他引脚均不变。
- 原理/目录/问题处理：技术总结.md；量化结论：验证结果.md；原始日志：evidence。
- 复现：在fpga-source目录执行scripts/verify-timing-latency.ps1，传入Python/ModelSim路径；加-Build执行隔离Gowin构建。
- 延迟为数字仿真。传感器物理检测、DAC和声学总延迟待实测，不宣称整机已经达标。

旧delivery-oled-integration文件保留，未推送远程仓库。
